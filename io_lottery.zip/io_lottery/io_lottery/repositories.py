class UserRepository:
    def add(self) -> None:
        raise NotImplementedError

class GetUserRepository:
    def get(self, id: int):
        raise NotImplementedError
